// script.js

/* ---------- Dark Mode ---------- */
const toggleBtn = document.getElementById("darkModeToggle");
const savedPref = localStorage.getItem("darkMode");
if (savedPref === "enabled") document.body.classList.add("dark");

toggleBtn?.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("darkMode",
    document.body.classList.contains("dark") ? "enabled" : "disabled");
});

/* ---------- SweetAlert CTA ---------- */
window.addEventListener("DOMContentLoaded", () => {
  const bookBtn = document.querySelector(".cta-button");
  if (bookBtn) {
    bookBtn.addEventListener("click", e => {
      e.preventDefault();
      Swal.fire("Booking page!", "Redirecting…", "info");
      setTimeout(() => (window.location.href = bookBtn.href), 1500);
    });
  }

  /* ---------- Doctor Search Filter ---------- */
  const searchBar = document.getElementById("searchBar");
  if (searchBar) {
    const cards = document.querySelectorAll(".doctor-card");
    searchBar.addEventListener("input", () => {
      const q = searchBar.value.toLowerCase();
      cards.forEach(card => {
        const name = card.querySelector("h3").textContent.toLowerCase();
        const spec = card.querySelector("p").textContent.toLowerCase();
        card.style.display = name.includes(q) || spec.includes(q) ? "block" : "none";
      });
    });
  }
});
