// booking.js
document.addEventListener("DOMContentLoaded", () => {
  const form      = document.getElementById("bookingForm");
  const steps     = document.querySelectorAll(".form-step");
  const indicators= document.querySelectorAll(".step");
  let current     = 0;

  /* -------- Stepper Nav -------- */
  const show = i => {
    steps.forEach((s,idx)=>s.classList.toggle("active",idx===i));
    indicators.forEach((d,idx)=>d.classList.toggle("active",idx===i));
  };
  document.querySelectorAll("[data-next]").forEach(btn=>btn.addEventListener("click",()=>{
    if(current<steps.length-1){current++;show(current);}
  }));
  document.querySelectorAll("[data-prev]").forEach(btn=>btn.addEventListener("click",()=>{
    if(current>0){current--;show(current);}
  }));

  /* -------- flatpickr -------- */
  flatpickr(".date-picker",{enableTime:true,minDate:"today",dateFormat:"d M Y h:i K"});

  /* -------- Doctors by Dept -------- */
  const deptSel = document.getElementById("departmentSelect");
  const docSel  = document.getElementById("doctorSelect");
  const map = {
    Cardiology:["Dr. Priya Mehta"],
    Neurology :["Dr. Rohan Singh"],
    Orthopedics:["Dr. Aman Patel"],
    Pediatrics:["Dr. Nidhi Sharma"]
  };
  deptSel.addEventListener("change",()=>{
    docSel.innerHTML='<option value="">-- Select Doctor --</option>';
    map[deptSel.value]?.forEach(d=>{
      const o=document.createElement("option");o.value=o.textContent=d;docSel.appendChild(o);
    });
  });

  /* -------- Auto‑fill doctor from URL param -------- */
  const params=new URLSearchParams(window.location.search);
  const docParam=params.get("doctor");
  if(docParam){
    deptSel.value=Object.keys(map).find(k=>map[k].includes(docParam))||"";
    deptSel.dispatchEvent(new Event("change"));
    docSel.value=docParam;
  }

  /* -------- Submit -------- */
  form.addEventListener("submit",e=>{
    e.preventDefault();
    const data={
      name :document.getElementById("patientName").value,
      email:document.getElementById("patientEmail").value,
      phone:document.getElementById("patientPhone").value,
      department:deptSel.value,
      doctor:docSel.value,
      date :document.getElementById("appointmentDate").value,
      time :document.getElementById("timeSlotSelect").value
    };
    localStorage.setItem("appointmentData",JSON.stringify(data));
    window.location.href="thankyou.html";   // ⬅️ new page
  });
});
