// thankyou.js
document.addEventListener("DOMContentLoaded", () => {
  const data = JSON.parse(localStorage.getItem("appointmentData"));
  const summaryDiv = document.getElementById("appointmentSummary");
  const pdfBtn = document.getElementById("downloadPDF");

  if (!data) {
    summaryDiv.innerHTML = "<p>No appointment data found.</p>";
    return;
  }

  const appointmentID = "APT" + Math.floor(100000 + Math.random() * 900000);

  // Show details on screen
  summaryDiv.innerHTML = `
    <p><strong>Appointment ID:</strong> ${appointmentID}</p>
    <p><strong>Name:</strong> ${data.name}</p>
    <p><strong>Email:</strong> ${data.email}</p>
    <p><strong>Phone:</strong> ${data.phone}</p>
    <p><strong>Department:</strong> ${data.department}</p>
    <p><strong>Doctor:</strong> ${data.doctor}</p>
    <p><strong>Date:</strong> ${data.date}</p>
    <p><strong>Time:</strong> ${data.time}</p>
  `;

  // Handle PDF Download
  pdfBtn.addEventListener("click", () => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Layout Styles
    doc.setFont("helvetica", "normal");
    doc.setFontSize(18);
    doc.setTextColor(0, 102, 128);
    doc.text("SmartCare Hospital", 20, 20);

    doc.setFontSize(14);
    doc.setTextColor(60);
    doc.text("Appointment Confirmation", 20, 30);

    doc.setDrawColor(0, 102, 128);
    doc.line(20, 35, 190, 35);

    let y = 50;
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`Appointment ID: ${appointmentID}`, 20, y); y += 10;
    doc.text(`Name: ${data.name}`, 20, y); y += 10;
    doc.text(`Email: ${data.email}`, 20, y); y += 10;
    doc.text(`Phone: ${data.phone}`, 20, y); y += 10;
    doc.text(`Department: ${data.department}`, 20, y); y += 10;
    doc.text(`Doctor: ${data.doctor}`, 20, y); y += 10;
    doc.text(`Date: ${data.date}`, 20, y); y += 10;
    doc.text(`Time: ${data.time}`, 20, y); y += 15;

    doc.setTextColor(0, 102, 128);
    doc.text("Thank you for choosing SmartCare Hospital!", 20, y); y += 15;

    doc.setTextColor(0);
    doc.text("Authorized Signature: ____________________", 20, y); y += 10;
    doc.text("Date: ____________________", 20, y);

    // QR Code Data
    const qrData = `
SmartCare Hospital
ID: ${appointmentID}
Name: ${data.name}
Doctor: ${data.doctor}
Date: ${data.date}
Time: ${data.time}
    `.trim();

    // Generate QR Code & Add to PDF
    QRCode.toDataURL(qrData, { width: 100 }, (err, url) => {
      if (!err) {
        doc.addImage(url, 'PNG', 140, 50, 50, 50); // Position right corner
      }

      // Save PDF
      doc.save(`SmartCare-${appointmentID}.pdf`);

      // Send Email using EmailJS
      emailjs.init("YOUR_EMAILJS_PUBLIC_KEY"); // ⚠️ replace with your public key
      emailjs.send("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", {
        to_name: data.name,
        to_email: data.email,
        message: `Hello ${data.name}, your appointment with ${data.doctor} on ${data.date} at ${data.time} is confirmed.\nAppointment ID: ${appointmentID}`
      }).then(() => {
        alert(`📩 Confirmation email sent to ${data.email}`);
      }).catch((error) => {
        console.error("EmailJS Error:", error);
      });
    });
  });
});
doc.setFont("helvetica", "bold");
doc.setFontSize(22);
doc.setTextColor(0, 128, 170); // Teal-blue
doc.text("🏥 SmartCare Hospital", 20, 25);

doc.setFontSize(14);
doc.setTextColor(100);
doc.setFont("helvetica", "normal");
doc.text("📋 Appointment Confirmation", 20, 35);

doc.setDrawColor(0, 128, 170);
doc.line(20, 40, 190, 40); // Divider line

doc.setFontSize(12);
doc.setTextColor(33, 33, 33);
let y = 55;
doc.text(`🆔 Appointment ID: ${appointmentID}`, 20, y); y += 10;
doc.text(`👤 Name: ${data.name}`, 20, y); y += 10;
doc.text(`📧 Email: ${data.email}`, 20, y); y += 10;
doc.text(`📱 Phone: ${data.phone}`, 20, y); y += 10;
doc.text(`🏥 Department: ${data.department}`, 20, y); y += 10;
doc.text(`👨‍⚕️ Doctor: ${data.doctor}`, 20, y); y += 10;
doc.text(`📅 Date: ${data.date}`, 20, y); y += 10;
doc.text(`⏰ Time: ${data.time}`, 20, y); y += 15;

doc.setTextColor(0, 128, 170);
doc.setFontSize(12);
doc.text("💙 Thank you for choosing SmartCare Hospital!", 20, y); y += 15;

doc.setTextColor(0);
doc.text("✍️ Authorized Signature: ____________________", 20, y); y += 10;
doc.text("📅 Date: ____________________", 20, y);

QRCode.toDataURL(qrData, { width: 100 }, function (err, url) {
  if (!err) {
    doc.addImage(url, 'PNG', 145, 50, 45, 45); // neater spacing
  }
  doc.save(`SmartCare-${appointmentID}.pdf`);
});


  // Handle PDF Download with UI enhancements
  pdfBtn.addEventListener("click", () => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // 🟦 Header with color
    doc.setFillColor(0, 102, 204); // Blue header
    doc.rect(0, 0, 210, 25, 'F');

    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.setTextColor(255, 255, 255);
    doc.text("🏥 SmartCare Hospital", 15, 17);

    // Title below header
    doc.setFontSize(14);
    doc.setTextColor(60);
    doc.setFont("helvetica", "normal");
    doc.text("Appointment Confirmation", 15, 35);

    // Divider
    doc.setDrawColor(0, 102, 204);
    doc.line(15, 38, 195, 38);

    let y = 50;
    doc.setFontSize(12);
    doc.setTextColor(30);

    doc.text(`🆔 Appointment ID: ${appointmentID}`, 20, y); y += 10;
    doc.text(`👤 Name: ${data.name}`, 20, y); y += 10;
    doc.text(`📧 Email: ${data.email}`, 20, y); y += 10;
    doc.text(`📞 Phone: ${data.phone}`, 20, y); y += 10;
    doc.text(`🏥 Department: ${data.department}`, 20, y); y += 10;
    doc.text(`👨‍⚕️ Doctor: ${data.doctor}`, 20, y); y += 10;
    doc.text(`📅 Date: ${data.date}`, 20, y); y += 10;
    doc.text(`⏰ Time: ${data.time}`, 20, y); y += 15;

    doc.setTextColor(0, 102, 128);
    doc.text("✅ Thank you for choosing SmartCare Hospital!", 20, y); y += 20;

    doc.setTextColor(0);
    doc.text("Authorized Signature: ____________________", 20, y); y += 10;
    doc.text("Date: ____________________", 20, y);

    // QR Code
    const qrData = `
SmartCare Hospital
ID: ${appointmentID}
Name: ${data.name}
Doctor: ${data.doctor}
Date: ${data.date}
Time: ${data.time}
    `.trim();

    QRCode.toDataURL(qrData, { width: 100 }, (err, url) => {
      if (!err) {
        doc.addImage(url, 'PNG', 145, 50, 50, 50); // Add QR
      }

      doc.save(`SmartCare-${appointmentID}.pdf`);

      // Email Send (unchanged)
      emailjs.init("YOUR_EMAILJS_PUBLIC_KEY"); // Replace
      emailjs.send("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", {
        to_name: data.name,
        to_email: data.email,
        message: `Hello ${data.name}, your appointment with ${data.doctor} on ${data.date} at ${data.time} is confirmed.\nAppointment ID: ${appointmentID}`
      }).then(() => {
        alert(`📩 Confirmation email sent to ${data.email}`);
      }).catch((error) => {
        console.error("EmailJS Error:", error);
      });
    });
  });

